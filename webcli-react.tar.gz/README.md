# webcli-react — Octra Wallet (React + Vite + WASM Port)

A full client-side port of [octra-labs/webcli](https://github.com/octra-labs/webcli) from a C++ HTTP server to a **React + Vite + TypeScript + WASM** browser app.

> **Status:** Core wallet features (create/import/unlock/send/balance/history/contract/stealth) are fully ported and tested. **PVAC FHE WASM module compiled and integrated** (653 KB) — some operations still stubbed pending cipher serialization API exposure. 6 AML contract templates included. CORS proxy implementations for Cloudflare Workers and Vercel Edge Function provided.

## Quickstart

```bash
cd webcli-react
npm install
npm run dev           # start Vite dev server (http://localhost:5173)
npm run dev:all       # dev server + vitest watch + auto-fix watcher (parallel)
npm test              # run 199 unit tests
npm run test:e2e      # run Playwright E2E tests (must `npm run build` first)
npm run build         # production build → dist/
npm run check         # typecheck + lint + test + build (all-in-one)
npm run autofix       # one-shot auto-fix (format + lint --fix + typecheck + test)
npm run autofix:watch # watch mode: re-run on every file save
npm run build:wasm    # compile PVAC C++ → WASM (requires Emscripten SDK)
```

## What's Ported

| C++ Source | TS Port | Status |
|------------|---------|--------|
| `crypto_utils.hpp` | `src/crypto/{ed25519,x25519,sha256,base58,base64,hex,bip39,hd,aes,address,random}.ts` | ✅ Complete |
| `wallet.hpp` | `src/wallet/{wallet,storage,pin}.ts` | ✅ Complete (IndexedDB replaces filesystem) |
| `lib/tx_builder.hpp` | `src/tx/{canonical-json,builder}.ts` | ✅ Complete (byte-exact canonical JSON) |
| `rpc_client.hpp` | `src/rpc/client.ts` | ✅ Complete (fetch-based, ~15 high-level methods) |
| `lib/stealth.hpp` | `src/stealth/index.ts` | ✅ Complete (ECDH, stealth tag, claim key, AES-GCM amount) |
| `lib/pvac_bridge.hpp` + `pvac/` | `src/pvac/{index,wasm-bridge}.ts` + `public/wasm/pvac.wasm` | ⚠️ Partial (WASM compiled; encrypt/keygen/commit work; decrypt/ctSub need cipher serialization API) |
| `main.cpp` HTTP routes | `src/api/{wallet-api,send}.ts` + React components | ✅ Complete (core routes) |
| `static/wallet.js` UI | `src/components/*.tsx` + `src/store/wallet-store.ts` | ✅ Complete (10 tabs: balance/send/history/stealth/accounts/backup/contract/viewer/circles/settings) |
| `static/templates/` (AML contracts) | `public/templates/{empty,token,vault,amm,escrow,multisig}/` | ✅ Complete (6 templates) |
| CORS handling | `cors-proxy/{cf-worker,vercel}/` | ✅ Ready-to-deploy (Cloudflare Workers + Vercel Edge) |

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Browser (no server — pure client-side)                     │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  React 18 UI (10 tab groups: Wallet/Contracts/Advanced)│  │
│  │  Zustand store (src/store/)                           │  │
│  └───────────────────────┬───────────────────────────────┘  │
│                          │ async calls                       │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │  API layer (src/api/)                                  │  │
│  │  - wallet-api.ts: create/import/unlock/derive          │  │
│  │  - send.ts: send/balance/history/fee                   │  │
│  └───────────────────────┬───────────────────────────────┘  │
│                          │                                   │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │  Crypto core (src/crypto/)                             │  │
│  │  - Ed25519 (tweetnacl)    - BIP39 (custom + WebCrypto) │  │
│  │  - X25519 ECDH (@noble)   - HD derivation (custom)     │  │
│  │  - SHA-256/512 (@noble)   - AES-256-GCM (WebCrypto)    │  │
│  │  - base58/64/hex          - PBKDF2 (WebCrypto)         │  │
│  └───────────────────────┬───────────────────────────────┘  │
│                          │                                   │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │  PVAC FHE (src/pvac/ + public/wasm/pvac.wasm)         │  │
│  │  - WASM module compiled from C++ via Emscripten       │  │
│  │  - Software AES fallback (no hardware AES in WASM)    │  │
│  │  - WasmPvacBridge wraps C API: keygen/encrypt/commit  │  │
│  └───────────────────────┬───────────────────────────────┘  │
│                          │                                   │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │  Transaction layer (src/tx/)                           │  │
│  │  - canonical-json.ts: byte-exact nlohmann::json match  │  │
│  │  - builder.ts: sign + verify + build JSON payload      │  │
│  └───────────────────────┬───────────────────────────────┘  │
│                          │                                   │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │  RPC client (src/rpc/client.ts)                        │  │
│  │  - fetch-based, ~15 high-level methods                 │  │
│  │  - Optional CORS proxy support                         │  │
│  └───────────────────────┬───────────────────────────────┘  │
│                          │ HTTPS                             │
└──────────────────────────┼──────────────────────────────────┘
                           │
                ┌──────────▼──────────┐
                │  Octra RPC Node     │
                │  (octra.network/rpc)│
                └─────────────────────┘
```

## PVAC WASM Compilation

The PVAC FHE library is now compiled to WebAssembly. The compile process:

1. **Prerequisite:** Install [Emscripten SDK](https://emscripten.org/docs/getting_started/downloads.html):
   ```bash
   git clone https://github.com/emscripten-core/emsdk.git /tmp/emsdk
   cd /tmp/emsdk && ./emsdk install latest && ./emsdk activate latest
   source /tmp/emsdk/emsdk_env.sh
   ```

2. **Get the PVAC source:**
   ```bash
   git clone https://github.com/octra-labs/webcli ../webcli-source
   ```

3. **Apply the software AES patch** (PVAC requires hardware AES by default; WASM has no AES instructions):
   ```bash
   python3 scripts/patch-pvac-aes.py ../webcli-source/pvac
   ```

4. **Compile:**
   ```bash
   bash scripts/build-wasm.sh
   ```
   Produces `public/wasm/pvac.wasm` (653 KB) and `public/wasm/pvac.js` (66 KB glue).

5. **Load in the app:** The Settings panel has a "Try Load PVAC WASM" button that calls `loadPvacWasm()`.

**Note:** The software AES fallback is ~5-10x slower than hardware AES. For production, consider running PVAC operations in a Web Worker to avoid blocking the UI.

## Storage

| Original (C++) | Port (Browser) |
|----------------|----------------|
| `data/wallet.oct` (AES-encrypted file) | IndexedDB `wallets` store (same AES-256-GCM format) |
| `data/accounts.json` (manifest) | IndexedDB `manifest` store |
| LevelDB TxCache | IndexedDB `tx-cache` store |
| `data/settings.json` | IndexedDB `settings` store |

All encryption is client-side via WebCrypto API. The PIN never leaves the browser.

**Wallet file export/import:** The Backup tab lets users download an encrypted `.oct` file and import it on another device/browser. The file format is identical to the C++ original (`OCT1` magic + version + PBKDF2 iterations + salt + nonce + AES-GCM ciphertext).

## Auto Test + Auto Fix + Auto Build

### Auto Test
- **Unit tests:** Vitest + jsdom + fake-indexeddb (199 tests across 15 files)
- **E2E tests:** Playwright (3 spec files: wallet-create, wallet-unlock, navigation)
- **Coverage:** V8 provider with 60% threshold (statements/branches/functions/lines)

### Auto Fix
- **`npm run autofix`**: One-shot — runs typecheck → format → lint --fix → tests
- **`npm run autofix:watch`**: Re-runs on every file save in `src/` and `tests/`
- **GitHub Actions `autofix` job**: On PRs, auto-commits formatting + lint fixes back to the branch

### Auto Build
- **`npm run build`**: Vite production build → `dist/` (350 KB total, 122 KB gzipped)
- **`npm run build:wasm`**: Emscripten compile of PVAC → `public/wasm/pvac.{wasm,js}`
- **GitHub Actions `build` job**: Runs on every push, uploads `dist/` as artifact
- **GitHub Actions `deploy` job**: Deploys to GitHub Pages on `main`/`master` push
- **CI pipeline**: test → build → e2e → deploy (all gated)

## Differences from Original C++

| Aspect | Original (C++) | Port (React) |
|--------|----------------|---------------|
| Server | Local C++ HTTP server on 127.0.0.1:8420 | None — pure client-side |
| Crypto | OpenSSL + TweetNaCl | WebCrypto + tweetnacl + @noble/curves |
| Ed25519↔X25519 | OpenSSL BIGNUM | @noble/curves `edwardsToMontgomeryPriv/Pub` |
| AES-256-GCM | OpenSSL EVP | WebCrypto subtle |
| PBKDF2 | OpenSSL PKCS5_PBKDF2_HMAC | WebCrypto subtle.deriveKey |
| Storage | Filesystem + LevelDB | IndexedDB |
| RPC | httplib::Client (no CORS) | fetch() — use provided CORS proxy if needed |
| PVAC (FHE) | Native C++ library | WASM (Emscripten compile + software AES fallback) |
| UI | Vanilla JS (4347 lines) | React 18 + Zustand + CSS (10 tabs) |
| Routes | 123 HTTP endpoints | Direct API function calls |
| AML templates | 6 in static/templates/ | 6 in public/templates/ (copied from source) |

## CORS Considerations

The Octra production RPC (`https://octra.network/rpc`) may not send CORS headers. Options:

1. **Deploy the included CORS proxy** — see `cors-proxy/README.md`:
   - **Cloudflare Workers** (recommended, free tier): `cors-proxy/cf-worker/`
   - **Vercel Edge Function**: `cors-proxy/vercel/`
2. **Self-host a thin proxy** alongside the static frontend
3. **Use the devnet** which historically has more permissive CORS

The `RpcClient` accepts an optional `proxyUrl` that prepends to all requests:
```typescript
new RpcClient({
  url: 'https://octra.network/rpc',
  proxyUrl: 'https://your-cors-proxy.workers.dev/proxy?url=', // optional
});
```

## What's NOT Ported (Yet)

| Feature | Reason | Roadmap |
|---------|--------|---------|
| PVAC decrypt/ctSub/verifyZeroProof | C API doesn't expose cipher serialization | Add serialize/deserialize functions to pvac_c_api.h, then wire to WasmPvacBridge |
| Circles full operations (63 endpoints) | Depends on PVAC cipher serialization | Phase 3 after PVAC is complete |
| Bridge / Relay | Depends on Circles | Phase 3 |
| PIN-required session lock | Currently PIN is re-entered per sensitive operation | Could add session timer |

## Testing the Build

```bash
npm run build && npm run preview
# Open http://localhost:4173
```

## License

GPL-2.0-only (inherited from the original `octra-labs/webcli`).

## Acknowledgments

- Original implementation: [octra-labs/webcli](https://github.com/octra-labs/webcli)
- Crypto backends: [tweetnacl](https://github.com/dchest/tweetnacl-js), [@noble/curves](https://github.com/paulmillr/noble-curves), [@noble/hashes](https://github.com/paulmillr/noble-hashes)
- Storage: [idb](https://github.com/jakearchibald/idb)
- Test infra: [Vitest](https://vitest.dev/), [Playwright](https://playwright.dev/), [fake-indexeddb](https://github.com/dumbmatter/fakeIndexedDB)
- WASM compile: [Emscripten](https://emscripten.org/)

