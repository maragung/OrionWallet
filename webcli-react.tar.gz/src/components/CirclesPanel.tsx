import { useEffect, useState } from 'react';
import { useWalletStore } from '../store/wallet-store';

interface CircleInfo {
  id: string;
  addr: string;
  type: string;
  created_at: number;
  program?: unknown;
}

export function CirclesPanel() {
  const { wallet, rpc, pushToast, setLoading } = useWalletStore();
  const [circles, setCircles] = useState<CircleInfo[]>([]);
  const [selectedCircle, setSelectedCircle] = useState<CircleInfo | null>(null);
  const [loading, setLoadingLocal] = useState(false);

  const refresh = async () => {
    if (!wallet || !rpc) return;
    setLoadingLocal(true);
    setLoading(true, 'Fetching circles...');
    try {
      // Try to get circles info for this address
      const r = await rpc.rpcCall<CircleInfo[]>('octra_circleInfo', [wallet.addr]);
      if (r.ok && r.result) {
        setCircles(Array.isArray(r.result) ? r.result : []);
      } else if (!r.ok && r.status !== 404) {
        pushToast('error', `Failed to fetch circles: ${r.error ?? 'unknown'}`);
      }
    } finally {
      setLoadingLocal(false);
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wallet, rpc]);

  if (!wallet) return null;

  return (
    <>
      <div className="card">
        <div className="card-header">
          <div className="card-title">Circles (Encrypted On-Chain Objects)</div>
          <button className="ghost" onClick={refresh} disabled={loading}>
            {loading ? <span className="spinner" /> : '↻ Refresh'}
          </button>
        </div>

        <div
          style={{
            marginBottom: 16,
            padding: 12,
            background: 'var(--bg-tertiary)',
            borderRadius: 8,
            fontSize: 13,
          }}
        >
          <strong>What are Circles?</strong>
          <br />
          Circles are encrypted on-chain objects/assets backed by HFHE (Homomorphic Encryption).
          They enable private state, sealed slots, key-grant access control, and cross-circle
          relays.
          <br />
          <br />
          <span className="tag warn">⚠️ Requires PVAC WASM for full functionality</span>
        </div>

        {circles.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 32, color: 'var(--text-muted)' }}>
            {loading ? 'Loading...' : 'No circles deployed by this wallet.'}
          </div>
        ) : (
          <table className="history-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Created</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {circles.map((c) => (
                <tr key={c.id} onClick={() => setSelectedCircle(c)} style={{ cursor: 'pointer' }}>
                  <td className="mono">{c.id.slice(0, 16)}…</td>
                  <td>
                    <span className="tag">{c.type}</span>
                  </td>
                  <td className="mono" style={{ color: 'var(--text-muted)' }}>
                    {new Date(c.created_at * 1000).toLocaleString()}
                  </td>
                  <td>
                    <button
                      className="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedCircle(c);
                      }}
                    >
                      View →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {selectedCircle && (
        <div className="card">
          <div className="card-header">
            <div className="card-title">Circle Details: {selectedCircle.id.slice(0, 16)}…</div>
            <button className="ghost" onClick={() => setSelectedCircle(null)}>
              Close
            </button>
          </div>
          <pre
            className="mono"
            style={{
              fontSize: 12,
              padding: 16,
              background: 'var(--bg-tertiary)',
              borderRadius: 8,
              overflowX: 'auto',
              color: 'var(--text-secondary)',
            }}
          >
            {JSON.stringify(selectedCircle, null, 2)}
          </pre>
        </div>
      )}
    </>
  );
}
