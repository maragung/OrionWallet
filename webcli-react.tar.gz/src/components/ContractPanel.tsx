import { useState } from 'react';
import { useWalletStore } from '../store/wallet-store';
import { signTransaction, buildTxJson, parseAmountRaw, recommendedOu, nowTs } from '../tx/builder';
import { isValidAddress } from '../crypto/address';

export function ContractPanel() {
  const { wallet, rpc, pushToast, setLoading } = useWalletStore();
  const [tab, setTab] = useState<'deploy' | 'call'>('deploy');
  const [source, setSource] = useState(
    '// AML contract source\ncontract Main {\n  field balance: map<address, u64>;\n}',
  );
  const [contractAddr, setContractAddr] = useState('');
  const [method, setMethod] = useState('');
  const [args, setArgs] = useState('{}');
  const [amount, setAmount] = useState('0');
  const [pin, setPin] = useState('');
  const [result, setResult] = useState<string | null>(null);

  if (!wallet) return null;

  const handleDeploy = async () => {
    if (!rpc) return pushToast('error', 'RPC not initialized');
    if (!pin) return pushToast('error', 'PIN required');
    if (!source.trim()) return pushToast('error', 'Source is empty');

    setLoading(true, 'Compiling & deploying contract...');
    try {
      // Step 1: compile on RPC node
      const compile = await rpc.compileAml(source);
      if (!compile.ok || !compile.result) {
        throw new Error(`Compile failed: ${compile.error}`);
      }
      const bytecode = compile.result.bytecode;

      // Step 2: build & sign program_deploy tx
      const bi = await rpc.getBalance(wallet.addr);
      if (!bi.ok || !bi.result) throw new Error('Cannot fetch nonce');
      const nonce = bi.result.nonce + 1;
      const fee = recommendedOu('program_deploy', 0n);
      const encryptedData = JSON.stringify({ bytecode });

      const tx = signTransaction({
        secretKey: wallet.sk,
        publicKeyB64: wallet.pubB64,
        fields: {
          from: wallet.addr,
          to: wallet.addr,
          amount: '0',
          nonce,
          ou: fee,
          timestamp: nowTs(),
          op_type: 'program_deploy',
          encrypted_data: encryptedData,
        },
      });

      const submit = await rpc.submitTx(JSON.parse(buildTxJson(tx)));
      if (!submit.ok || !submit.result) throw new Error(`Submit failed: ${submit.error}`);

      setResult(tx.hash);
      pushToast('success', `Contract deployed (hash=${tx.hash.slice(0, 12)}...)`);
    } catch (e) {
      pushToast('error', `Deploy failed: ${(e as Error).message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleCall = async () => {
    if (!rpc) return pushToast('error', 'RPC not initialized');
    if (!isValidAddress(contractAddr)) return pushToast('error', 'Invalid contract address');
    if (!method) return pushToast('error', 'Method name required');
    if (!pin) return pushToast('error', 'PIN required');

    setLoading(true, 'Calling contract...');
    try {
      let argsObj: unknown = undefined;
      try {
        argsObj = args.trim() ? JSON.parse(args) : undefined;
      } catch {
        throw new Error('Args must be valid JSON');
      }
      const amountRaw = parseAmountRaw(amount || '0');
      const bi = await rpc.getBalance(wallet.addr);
      if (!bi.ok || !bi.result) throw new Error('Cannot fetch nonce');
      const nonce = bi.result.nonce + 1;
      const fee = recommendedOu('program_call', 0n);
      const encryptedData = JSON.stringify({ method, args: argsObj });

      const tx = signTransaction({
        secretKey: wallet.sk,
        publicKeyB64: wallet.pubB64,
        fields: {
          from: wallet.addr,
          to: contractAddr,
          amount: amountRaw,
          nonce,
          ou: fee,
          timestamp: nowTs(),
          op_type: 'program_call',
          encrypted_data: encryptedData,
        },
      });

      const submit = await rpc.submitTx(JSON.parse(buildTxJson(tx)));
      if (!submit.ok || !submit.result) throw new Error(`Submit failed: ${submit.error}`);

      setResult(tx.hash);
      pushToast('success', `Contract called (hash=${tx.hash.slice(0, 12)}...)`);
    } catch (e) {
      pushToast('error', `Call failed: ${(e as Error).message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title">Smart Contracts (AML)</div>
      </div>

      <div className="tab-bar">
        <div className={`tab ${tab === 'deploy' ? 'active' : ''}`} onClick={() => setTab('deploy')}>
          Deploy
        </div>
        <div className={`tab ${tab === 'call' ? 'active' : ''}`} onClick={() => setTab('call')}>
          Call
        </div>
      </div>

      {tab === 'deploy' ? (
        <>
          <div className="form-row">
            <label htmlFor="source">AML Source Code</label>
            <textarea
              id="source"
              className="mono"
              rows={12}
              value={source}
              onChange={(e) => setSource(e.target.value)}
              spellCheck={false}
            />
          </div>
          <div className="form-row">
            <label htmlFor="pin">PIN</label>
            <input
              id="pin"
              type="password"
              className="mono"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
            />
          </div>
          <div className="form-actions">
            <button className="primary" onClick={handleDeploy} disabled={!source || !pin}>
              Compile & Deploy
            </button>
          </div>
        </>
      ) : (
        <>
          <div className="form-row">
            <label htmlFor="addr">Contract Address</label>
            <input
              id="addr"
              className="mono"
              value={contractAddr}
              onChange={(e) => setContractAddr(e.target.value)}
              placeholder="oct..."
            />
          </div>
          <div className="form-row">
            <label htmlFor="method">Method Name</label>
            <input
              id="method"
              className="mono"
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              placeholder="transfer"
            />
          </div>
          <div className="form-row">
            <label htmlFor="args">Arguments (JSON)</label>
            <textarea
              id="args"
              className="mono"
              rows={4}
              value={args}
              onChange={(e) => setArgs(e.target.value)}
              spellCheck={false}
            />
          </div>
          <div className="form-row">
            <label htmlFor="amt">Amount (OCT, sent with call)</label>
            <input
              id="amt"
              className="mono"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              inputMode="decimal"
            />
          </div>
          <div className="form-row">
            <label htmlFor="pin2">PIN</label>
            <input
              id="pin2"
              type="password"
              className="mono"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
            />
          </div>
          <div className="form-actions">
            <button
              className="primary"
              onClick={handleCall}
              disabled={!contractAddr || !method || !pin}
            >
              Sign & Call
            </button>
          </div>
        </>
      )}

      {result && (
        <div
          style={{ marginTop: 16, padding: 12, background: 'var(--bg-tertiary)', borderRadius: 8 }}
        >
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 4 }}>
            Transaction Hash
          </div>
          <div className="mono" style={{ fontSize: 12, wordBreak: 'break-all' }}>
            {result}
          </div>
        </div>
      )}
    </div>
  );
}
