import { useEffect, useState } from 'react';
import { useWalletStore } from '../store/wallet-store';
import { UnlockWallet } from './UnlockWallet';
import { CreateWallet } from './CreateWallet';
import { BalanceView } from './BalanceView';
import { SendForm } from './SendForm';
import { HistoryView } from './HistoryView';
import { ContractPanel } from './ContractPanel';
import { ContractViewer } from './ContractViewer';
import { StealthPanel } from './StealthPanel';
import { SettingsPanel } from './SettingsPanel';
import { AccountSwitcher } from './AccountSwitcher';
import { CirclesPanel } from './CirclesPanel';
import { WalletExportImport } from './WalletExportImport';
import { Toasts } from './Toasts';
import { LoadingOverlay } from './LoadingOverlay';
import { ThemeToggle } from './ThemeToggle';
import { LanguageSwitcher } from './LanguageSwitcher';
import { useTheme } from '../hooks/useTheme';
import { useI18n } from '../i18n/useI18n';

type Tab =
  | 'balance'
  | 'send'
  | 'history'
  | 'contract'
  | 'contract-viewer'
  | 'stealth'
  | 'circles'
  | 'accounts'
  | 'export-import'
  | 'settings';

interface NavItem {
  id: Tab;
  labelKey: string;
  shortLabelKey: string;
  icon: string;
  group: 'Wallet' | 'Contracts' | 'Advanced';
  mobile?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  {
    id: 'balance',
    labelKey: 'nav.balance',
    shortLabelKey: 'nav.home',
    icon: '💰',
    group: 'Wallet',
    mobile: true,
  },
  {
    id: 'send',
    labelKey: 'nav.send',
    shortLabelKey: 'nav.send',
    icon: '📤',
    group: 'Wallet',
    mobile: true,
  },
  {
    id: 'history',
    labelKey: 'nav.history',
    shortLabelKey: 'nav.history',
    icon: '📜',
    group: 'Wallet',
    mobile: true,
  },
  {
    id: 'stealth',
    labelKey: 'nav.stealth',
    shortLabelKey: 'nav.stealth',
    icon: '🤫',
    group: 'Wallet',
  },
  {
    id: 'accounts',
    labelKey: 'nav.accounts',
    shortLabelKey: 'nav.accounts',
    icon: '👥',
    group: 'Wallet',
  },
  {
    id: 'export-import',
    labelKey: 'nav.backup',
    shortLabelKey: 'nav.backup',
    icon: '💾',
    group: 'Wallet',
  },
  {
    id: 'contract',
    labelKey: 'nav.deploy',
    shortLabelKey: 'nav.deploy',
    icon: '📄',
    group: 'Contracts',
  },
  {
    id: 'contract-viewer',
    labelKey: 'nav.viewer',
    shortLabelKey: 'nav.viewer',
    icon: '🔍',
    group: 'Contracts',
  },
  {
    id: 'circles',
    labelKey: 'nav.circles',
    shortLabelKey: 'nav.circles',
    icon: '⭕',
    group: 'Advanced',
    mobile: true,
  },
  {
    id: 'settings',
    labelKey: 'nav.settings',
    shortLabelKey: 'nav.settings',
    icon: '⚙️',
    group: 'Advanced',
    mobile: true,
  },
];

function NavGroup({
  title,
  items,
  tab,
  setTab,
  t,
}: {
  title: string;
  items: NavItem[];
  tab: Tab;
  setTab: (t: Tab) => void;
  t: (key: string) => string;
}) {
  if (items.length === 0) return null;
  return (
    <div style={{ marginTop: 'var(--sp-2)' }}>
      <div className="nav-group-label">{title}</div>
      {items.map((item) => (
        <div
          key={item.id}
          className={`nav-item ${tab === item.id ? 'active' : ''}`}
          onClick={() => setTab(item.id)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setTab(item.id);
            }
          }}
        >
          <span className="icon">{item.icon}</span>
          <span>{t(item.labelKey)}</span>
        </div>
      ))}
    </div>
  );
}

/** Mobile bottom navigation — shows only items flagged with `mobile: true`. */
function MobileNav({
  tab,
  setTab,
  t,
}: {
  tab: Tab;
  setTab: (t: Tab) => void;
  t: (key: string) => string;
}) {
  const items = NAV_ITEMS.filter((i) => i.mobile);
  return (
    <nav className="mobile-nav" aria-label="Mobile navigation">
      {items.map((item) => (
        <div
          key={item.id}
          className={`mobile-nav-item ${tab === item.id ? 'active' : ''}`}
          onClick={() => setTab(item.id)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setTab(item.id);
            }
          }}
        >
          <span className="icon">{item.icon}</span>
          <span className="label">{t(item.shortLabelKey)}</span>
        </div>
      ))}
    </nav>
  );
}

export function Layout() {
  const [tab, setTab] = useState<Tab>('balance');
  const [showCreate, setShowCreate] = useState(false);
  const { t } = useI18n();
  const {
    wallet,
    isUnlocked,
    initRpc,
    settings,
    lock,
    isLoading,
    loadingMessage,
    pvacStatus,
    pvacError,
  } = useWalletStore();

  // Initialize theme system (applies data-theme to <html>)
  useTheme();

  // Reset showCreate when wallet is locked
  useEffect(() => {
    if (!isUnlocked) {
      setShowCreate(false);
      setTab('balance');
    }
  }, [isUnlocked]);

  useEffect(() => {
    initRpc().catch((e) => {
      console.error('initRpc failed:', e);
    });
  }, [initRpc]);

  if (!isUnlocked || !wallet) {
    return (
      <>
        {showCreate ? (
          <CreateWallet onBack={() => setShowCreate(false)} />
        ) : (
          <UnlockWallet onCreate={() => setShowCreate(true)} />
        )}
        <Toasts />
        <LoadingOverlay loading={isLoading} message={loadingMessage} />
      </>
    );
  }

  // Group nav items for desktop sidebar
  const walletItems = NAV_ITEMS.filter((i) => i.group === 'Wallet');
  const contractItems = NAV_ITEMS.filter((i) => i.group === 'Contracts');
  const advancedItems = NAV_ITEMS.filter((i) => i.group === 'Advanced');

  // PVAC status indicator for header
  const pvacIndicator = (() => {
    switch (pvacStatus) {
      case 'loading':
        return (
          <span className="tag info" title="Loading PVAC WASM module">
            <span className="spinner" style={{ width: 8, height: 8, marginRight: 4 }} />
            PVAC…
          </span>
        );
      case 'ready':
        return (
          <span className="tag ok" title="PVAC WASM loaded and bridge initialized">
            ● PVAC
          </span>
        );
      case 'failed':
        return (
          <span className="tag err" title={`PVAC failed: ${pvacError ?? ''}`}>
            ● PVAC
          </span>
        );
      case 'unavailable':
        return (
          <span className="tag warn" title="PVAC WASM not compiled — run `npm run build:wasm`">
            ○ PVAC
          </span>
        );
      default:
        return null;
    }
  })();

  return (
    <div className="app">
      <header className="app-header">
        <div className="brand">
          <img src="/icons/wallet.svg" alt="Octra" />
          <span>Octra WebCLI</span>
          <span className="tag info">React Port</span>
          {pvacIndicator}
        </div>
        <div className="actions">
          <span className="network-pill">
            {settings?.network === 'devnet' ? 'DEVNET' : 'MAINNET'}
          </span>
          <LanguageSwitcher />
          <ThemeToggle />
          <button
            className="ghost icon"
            onClick={() => navigator.clipboard.writeText(wallet.addr)}
            title={t('common.copy')}
            aria-label={t('common.copy')}
          >
            📋
          </button>
          <button className="ghost icon" onClick={lock} title="🔒" aria-label="Lock">
            🔒
          </button>
        </div>
      </header>

      <aside className="app-sidebar">
        <NavGroup title={t('nav.wallet')} items={walletItems} tab={tab} setTab={setTab} t={t} />
        <NavGroup
          title={t('nav.contracts')}
          items={contractItems}
          tab={tab}
          setTab={setTab}
          t={t}
        />
        <NavGroup title={t('nav.advanced')} items={advancedItems} tab={tab} setTab={setTab} t={t} />
      </aside>

      <main className="app-main">
        {tab === 'balance' && <BalanceView />}
        {tab === 'send' && <SendForm />}
        {tab === 'history' && <HistoryView />}
        {tab === 'stealth' && <StealthPanel />}
        {tab === 'accounts' && <AccountSwitcher />}
        {tab === 'export-import' && <WalletExportImport />}
        {tab === 'contract' && <ContractPanel />}
        {tab === 'contract-viewer' && <ContractViewer />}
        {tab === 'circles' && <CirclesPanel />}
        {tab === 'settings' && <SettingsPanel />}
      </main>

      <MobileNav tab={tab} setTab={setTab} t={t} />

      <Toasts />
      <LoadingOverlay loading={isLoading} message={loadingMessage} />
    </div>
  );
}
