import { useEffect, useState } from 'react';
import { useWalletStore } from '../store/wallet-store';
import { getHistory } from '../api/send';
import { formatAmount } from '../tx/builder';
import type { HistoryEntry } from '../rpc/client';
import { Tooltip } from './Tooltip';

export function HistoryView() {
  const { wallet, rpc, pushToast } = useWalletStore();
  const [entries, setEntries] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [usingCache, setUsingCache] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const refresh = async () => {
    if (!wallet || !rpc) return;
    setLoading(true);
    setError(null);
    setUsingCache(false);
    try {
      const list = await getHistory(rpc, wallet.addr, { limit: 50, useCache: true });
      setEntries(list);
      setLastUpdated(new Date());
    } catch (e) {
      const msg = (e as Error).message;
      setError(msg);
      // Try to load from cache
      try {
        const { listTxCache } = await import('../wallet/storage');
        const cached = await listTxCache(wallet.addr, 50);
        if (cached.length > 0) {
          setEntries(cached.map((c) => c.tx as HistoryEntry));
          setUsingCache(true);
          pushToast('warning', 'Showing cached transactions (network unavailable)');
        }
      } catch {
        // no cache available
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wallet, rpc]);

  if (!wallet) return null;

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title">
          📜 Transaction History{' '}
          <Tooltip text="Recent transactions for this wallet. Shows incoming and outgoing transfers, contract calls, and stealth payments. Updates on page load — click refresh for latest.">
            <span style={{ color: 'var(--text-muted)', cursor: 'help', fontSize: 'var(--fs-sm)' }}>
              ⓘ
            </span>
          </Tooltip>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-2)' }}>
          {lastUpdated && !loading && (
            <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>
              {usingCache ? '⚠ Cached' : `Updated ${lastUpdated.toLocaleTimeString()}`}
            </span>
          )}
          <button className="ghost icon" onClick={refresh} disabled={loading} title="Refresh">
            {loading ? <span className="spinner" /> : '↻'}
          </button>
        </div>
      </div>

      {loading && entries.length === 0 ? (
        // Skeleton loaders
        <div>
          {[1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              style={{
                display: 'flex',
                gap: 'var(--sp-3)',
                padding: 'var(--sp-3) 0',
                borderBottom: '1px solid var(--border-subtle)',
              }}
            >
              <div
                className="skeleton"
                style={{ width: 60, height: 24, borderRadius: 'var(--r-sm)' }}
              />
              <div
                className="skeleton"
                style={{ flex: 1, height: 14, borderRadius: 'var(--r-sm)' }}
              />
              <div
                className="skeleton"
                style={{ width: 80, height: 14, borderRadius: 'var(--r-sm)' }}
              />
              <div
                className="skeleton"
                style={{ width: 60, height: 20, borderRadius: 'var(--r-sm)' }}
              />
            </div>
          ))}
          <div
            style={{
              textAlign: 'center',
              padding: 'var(--sp-3)',
              color: 'var(--text-muted)',
              fontSize: 'var(--fs-sm)',
            }}
          >
            Loading transactions...
          </div>
        </div>
      ) : error && entries.length === 0 ? (
        <div className="empty-state" style={{ padding: 'var(--sp-8)', color: 'var(--error)' }}>
          <div className="icon">⚠️</div>
          <div className="title">Failed to load history</div>
          <div className="desc">{error}</div>
          <button className="ghost" style={{ marginTop: 'var(--sp-3)' }} onClick={refresh}>
            ↻ Retry
          </button>
        </div>
      ) : entries.length === 0 ? (
        <div className="empty-state">
          <div className="icon">📭</div>
          <div className="title">No transactions yet</div>
          <div className="desc">
            Your transaction history will appear here once you send or receive OCT.
            <br />
            New transactions typically appear within a few seconds after submission.
          </div>
        </div>
      ) : (
        <>
          {usingCache && (
            <div
              className="info-box warn"
              style={{
                marginBottom: 'var(--sp-3)',
                display: 'flex',
                alignItems: 'center',
                gap: 'var(--sp-2)',
              }}
            >
              <span>⚠️</span>
              <span>Showing cached data — network unavailable. Click refresh to retry.</span>
            </div>
          )}
          <div style={{ overflowX: 'auto' }}>
            <table className="history-table">
              <thead>
                <tr>
                  <th>Hash</th>
                  <th>Type</th>
                  <th>From</th>
                  <th>To</th>
                  <th style={{ textAlign: 'right' }}>Amount</th>
                  <th style={{ textAlign: 'right' }}>Fee</th>
                  <th>Status</th>
                  <th>Time</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((tx) => {
                  const isIncoming = tx.to === wallet.addr;
                  const isOutgoing = tx.from === wallet.addr;
                  return (
                    <tr key={tx.hash}>
                      <td className="mono" title={tx.hash}>
                        {tx.hash.slice(0, 10)}…
                      </td>
                      <td>
                        <span className="badge">{tx.op_type}</span>
                      </td>
                      <td className="mono" title={tx.from}>
                        {isOutgoing ? (
                          <span className="tag ok">self</span>
                        ) : (
                          `${tx.from.slice(0, 8)}…`
                        )}
                      </td>
                      <td className="mono" title={tx.to}>
                        {isIncoming ? (
                          <span className="tag ok">self</span>
                        ) : (
                          `${tx.to.slice(0, 8)}…`
                        )}
                      </td>
                      <td
                        className="mono"
                        style={{
                          textAlign: 'right',
                          color: isIncoming ? 'var(--success)' : 'inherit',
                        }}
                      >
                        {isIncoming ? '+' : ''}
                        {formatAmount(tx.amount)}
                      </td>
                      <td
                        className="mono"
                        style={{ textAlign: 'right', color: 'var(--text-muted)' }}
                      >
                        {formatAmount(tx.ou)}
                      </td>
                      <td>
                        <span className={`badge ${tx.status ?? 'pending'}`}>
                          {tx.status ?? 'pending'}
                        </span>
                      </td>
                      <td
                        className="mono"
                        style={{ color: 'var(--text-muted)', whiteSpace: 'nowrap' }}
                      >
                        {new Date(tx.timestamp * 1000).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div
            style={{
              marginTop: 'var(--sp-3)',
              fontSize: 'var(--fs-xs)',
              color: 'var(--text-muted)',
              textAlign: 'center',
            }}
          >
            Showing {entries.length} of {entries.length} transactions
          </div>
        </>
      )}
    </div>
  );
}
