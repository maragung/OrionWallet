import { useState } from 'react';
import { useWalletStore } from '../store/wallet-store';
import { signTransaction, buildTxJson, parseAmountRaw, recommendedOu, nowTs } from '../tx/builder';
import { isValidAddress } from '../crypto/address';
import { prepareStealthSend } from '../stealth';
import { base64Decode } from '../crypto/base64';

export function StealthPanel() {
  const { wallet, rpc, pushToast, setLoading, pvacBridgeReady } = useWalletStore();
  const [to, setTo] = useState('');
  const [amount, setAmount] = useState('');
  const [pin, setPin] = useState('');
  const [result, setResult] = useState<string | null>(null);

  if (!wallet) return null;

  const handleSend = async () => {
    if (!rpc) return pushToast('error', 'RPC not initialized');
    if (!isValidAddress(to)) return pushToast('error', 'Invalid recipient address');
    if (!amount) return pushToast('error', 'Amount required');
    if (!pin) return pushToast('error', 'PIN required');

    setLoading(true, 'Preparing stealth send...');
    try {
      const amountRaw = parseAmountRaw(amount);
      if (BigInt(amountRaw) <= 0n) throw new Error('Amount must be positive');

      // Step 1: Fetch recipient's Ed25519 public key
      const pkResp = await rpc.getPublicKey(to);
      if (!pkResp.ok || !pkResp.result?.public_key) {
        throw new Error(`Cannot fetch recipient public key: ${pkResp.error ?? 'unknown'}`);
      }
      const recipientEdPub = base64Decode(pkResp.result.public_key);
      if (recipientEdPub.length !== 32) {
        throw new Error('Recipient public key is not 32 bytes');
      }

      // Step 2: Prepare stealth send (ephemeral ECDH + amount encryption)
      const prepared = await prepareStealthSend({
        recipientEd25519Pubkey: recipientEdPub,
        amountRaw,
      });

      // Step 3: Build & sign stealth tx
      const bi = await rpc.getBalance(wallet.addr);
      if (!bi.ok || !bi.result) throw new Error('Cannot fetch nonce');
      const nonce = bi.result.nonce + 1;
      const fee = recommendedOu('stealth', BigInt(amountRaw));
      const encryptedData = JSON.stringify({
        ephemeral_pubkey: prepared.ephemeralPubkeyB64,
        stealth_tag: prepared.stealthTagHex,
        claim_pub: prepared.claimPubB64,
        amount_payload: prepared.amountPayload,
      });

      const tx = signTransaction({
        secretKey: wallet.sk,
        publicKeyB64: wallet.pubB64,
        fields: {
          from: wallet.addr,
          to, // recipient address (visible, but amount is hidden)
          amount: amountRaw,
          nonce,
          ou: fee,
          timestamp: nowTs(),
          op_type: 'stealth',
          encrypted_data: encryptedData,
        },
      });

      const submit = await rpc.submitTx(JSON.parse(buildTxJson(tx)));
      if (!submit.ok || !submit.result) throw new Error(`Submit failed: ${submit.error}`);

      setResult(tx.hash);
      pushToast('success', `Stealth transaction submitted (hash=${tx.hash.slice(0, 12)}...)`);
      setTo('');
      setAmount('');
      setPin('');
    } catch (e) {
      pushToast('error', `Stealth send failed: ${(e as Error).message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title">Stealth Send</div>
      </div>

      <div
        style={{
          marginBottom: 16,
          padding: 12,
          background: 'var(--bg-tertiary)',
          borderRadius: 8,
          fontSize: 13,
        }}
      >
        <strong>How it works:</strong> Stealth sends use ephemeral X25519 ECDH to derive a one-time
        stealth tag and claim key. The amount is encrypted with AES-256-GCM and only the recipient
        can decrypt it (by scanning the chain for matching stealth tags).
        <br />
        <br />
        {!pvacBridgeReady && (
          <span className="tag warn">
            ⚠️ PVAC bridge not ready — sender-side FHE balance subtraction is disabled. Stealth send
            still works for recipients with public balance.
          </span>
        )}
      </div>

      <div className="form-row">
        <label htmlFor="sto">Recipient Address</label>
        <input
          id="sto"
          className="mono"
          value={to}
          onChange={(e) => setTo(e.target.value)}
          placeholder="oct..."
        />
      </div>

      <div className="form-row">
        <label htmlFor="samt">Amount (OCT, will be encrypted)</label>
        <input
          id="samt"
          className="mono"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="1.5"
          inputMode="decimal"
        />
      </div>

      <div className="form-row">
        <label htmlFor="spin">PIN</label>
        <input
          id="spin"
          type="password"
          className="mono"
          value={pin}
          onChange={(e) => setPin(e.target.value)}
        />
      </div>

      <div className="form-actions">
        <button className="primary" onClick={handleSend} disabled={!to || !amount || !pin}>
          Send Stealth
        </button>
      </div>

      {result && (
        <div
          style={{ marginTop: 16, padding: 12, background: 'var(--bg-tertiary)', borderRadius: 8 }}
        >
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 4 }}>
            Transaction Hash
          </div>
          <div className="mono" style={{ fontSize: 12, wordBreak: 'break-all' }}>
            {result}
          </div>
        </div>
      )}
    </div>
  );
}
