import { useState } from 'react';
import { useWalletStore } from '../store/wallet-store';
import { isValidAddress } from '../crypto/address';

export function ContractViewer() {
  const { rpc, pushToast, setLoading } = useWalletStore();
  const [addr, setAddr] = useState('');
  const [info, setInfo] = useState<unknown>(null);
  const [storage, setStorage] = useState<unknown>(null);
  const [loading, setLoadingLocal] = useState(false);

  const lookup = async () => {
    if (!rpc) return pushToast('error', 'RPC not initialized');
    if (!isValidAddress(addr)) return pushToast('error', 'Invalid contract address');
    setLoadingLocal(true);
    setLoading(true, 'Looking up contract...');
    setInfo(null);
    setStorage(null);
    try {
      const [infoR, storageR] = await Promise.all([
        rpc.getProgramInfo(addr),
        rpc.getContractStorage(addr),
      ]);
      if (infoR.ok) setInfo(infoR.result);
      else pushToast('warning', `Program info: ${infoR.error ?? 'not found'}`);
      if (storageR.ok) setStorage(storageR.result);
      else pushToast('warning', `Storage: ${storageR.error ?? 'not found'}`);
    } catch (e) {
      pushToast('error', `Lookup failed: ${(e as Error).message}`);
    } finally {
      setLoadingLocal(false);
      setLoading(false);
    }
  };

  // Helper to render arbitrary JSON nicely
  const renderJson = (label: string, data: unknown) => {
    if (data === null || data === undefined) return null;
    return (
      <div style={{ marginTop: 12 }}>
        <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 4 }}>{label}</div>
        <pre
          className="mono"
          style={{
            fontSize: 12,
            padding: 12,
            background: 'var(--bg-tertiary)',
            borderRadius: 8,
            overflowX: 'auto',
            color: 'var(--text-secondary)',
            maxHeight: 400,
          }}
        >
          {typeof data === 'string' ? data : JSON.stringify(data, null, 2)}
        </pre>
      </div>
    );
  };

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title">Contract Viewer</div>
      </div>

      <div className="form-row">
        <label htmlFor="caddr">Contract Address</label>
        <input
          id="caddr"
          className="mono"
          value={addr}
          onChange={(e) => setAddr(e.target.value)}
          placeholder="oct..."
          onKeyDown={(e) => e.key === 'Enter' && lookup()}
          style={addr && !isValidAddress(addr) ? { borderColor: 'var(--error)' } : undefined}
        />
      </div>

      <div className="form-actions" style={{ justifyContent: 'flex-start' }}>
        <button className="primary" onClick={lookup} disabled={!addr || loading}>
          {loading ? <span className="spinner" /> : 'Look Up'}
        </button>
      </div>

      {renderJson('Program Info', info)}
      {renderJson('Contract Storage', storage)}
    </div>
  );
}
