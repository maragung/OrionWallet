/**
 * Octra transaction types and builder.
 * Ported from lib/tx_builder.hpp (Transaction struct, sign_transaction, build_tx_json).
 */
import { sign, verify } from '../crypto/ed25519';
import { base64Decode } from '../crypto/base64';
import { hexEncode, hexDecode } from '../crypto/hex';
import { sha256 } from '../crypto/sha256';
import { canonicalJsonForTx, computeTxHash, type TransactionFields } from './canonical-json';

/** Operation types supported by Octra. */
export type OpType =
  | 'standard'
  | 'encrypt'
  | 'decrypt'
  | 'stealth'
  | 'key_switch'
  | 'program_deploy'
  | 'program_call'
  | 'circle_deploy'
  | 'circle_update'
  | 'circle_asset_put'
  | 'circle_relay'
  | 'register_pvac';

/** A complete Octra transaction with signature. */
export interface Transaction extends TransactionFields {
  /** Hex-encoded Ed25519 signature over canonical_json. */
  signature: string;
  /** Hex-encoded SHA-256 of canonical_json (the tx hash). */
  hash: string;
  /** Base64-encoded Ed25519 public key of the sender. */
  public_key: string;
}

/** Signing inputs (everything needed to produce a signed transaction). */
export interface SignTxInputs {
  /** Sender Ed25519 secret key (64 bytes = seed||pub). */
  secretKey: Uint8Array;
  /** Sender Ed25519 public key (32 bytes), base64-encoded. */
  publicKeyB64: string;
  /** Transaction fields (without signature/hash/public_key). */
  fields: TransactionFields;
}

/** Sign a transaction.
 * Produces the canonical JSON, signs with Ed25519, and returns the full
 * signed transaction (with signature, hash, and public_key populated).
 */
export function signTransaction(inputs: SignTxInputs): Transaction {
  const canon = canonicalJsonForTx(inputs.fields);
  const sig = sign(canon, inputs.secretKey);
  const hash = hexEncode(sha256(canon));
  return {
    ...inputs.fields,
    signature: hexEncode(sig),
    hash,
    public_key: inputs.publicKeyB64,
  };
}

/** Verify a transaction signature. */
export function verifyTransaction(tx: Transaction): boolean {
  try {
    const pub = base64Decode(tx.public_key);
    if (pub.length !== 32) return false;
    const sig = hexDecode(tx.signature);
    if (sig.length !== 64) return false;
    const canon = canonicalJsonForTx(tx);
    return verify(canon, sig, pub);
  } catch {
    return false;
  }
}

/** Build the JSON payload to submit to the RPC node (full signed tx as JSON). */
export function buildTxJson(tx: Transaction): string {
  // The RPC expects the full transaction as a JSON object.
  // Field order matches the C++ build_tx_json for compatibility.
  const knownKeys = new Set([
    'from',
    'to',
    'amount',
    'nonce',
    'ou',
    'timestamp',
    'op_type',
    'signature',
    'hash',
    'public_key',
    'message',
    'encrypted_data',
  ]);
  const ordered: Array<[string, unknown]> = [
    ['from', tx.from],
    ['to', tx.to],
    ['amount', tx.amount],
    ['nonce', tx.nonce],
    ['ou', tx.ou],
    ['timestamp', tx.timestamp],
    ['op_type', tx.op_type],
    ['signature', tx.signature],
    ['hash', tx.hash],
    ['public_key', tx.public_key],
  ];
  if (tx.message) ordered.push(['message', tx.message]);
  if (tx.encrypted_data) ordered.push(['encrypted_data', tx.encrypted_data]);
  for (const [k, v] of Object.entries(tx)) {
    if (knownKeys.has(k)) continue;
    ordered.push([k, v]);
  }
  const obj: Record<string, unknown> = {};
  for (const [k, v] of ordered) obj[k] = v;
  return JSON.stringify(obj);
}

/**
 * Compute the recommended OU (fee) for a given operation type and amount.
 * Ported from main.cpp parse_ou / recommended_ou_for_op.
 *
 * The Octra devnet RPC returns fee schedule with "recommended" and "fast" values.
 * For simplicity, we use hardcoded defaults that match typical Octra fees:
 *   standard:   10000 raw (0.01 OCT)
 *   encrypt:    1000000 raw (1 OCT)
 *   stealth:    1000000 raw (1 OCT)
 *   program_deploy: 5000000 raw (5 OCT)
 *   program_call:   100000 raw (0.1 OCT)
 *
 * These can be overridden by the user in the Send form.
 */
export function recommendedOu(opType: string, amountRaw: number | bigint): string {
  const amt = typeof amountRaw === 'bigint' ? amountRaw : BigInt(amountRaw);
  switch (opType) {
    case 'standard':
      return amt < 1_000_000_000n ? '10000' : '30000';
    case 'encrypt':
    case 'decrypt':
    case 'stealth':
    case 'key_switch':
      return '1000000';
    case 'program_deploy':
    case 'circle_deploy':
      return '5000000';
    case 'program_call':
    case 'register_pvac':
      return '100000';
    case 'circle_update':
    case 'circle_relay':
      return '1000000';
    case 'circle_asset_put':
      return '500000';
    default:
      return '10000';
  }
}

/** Parse a human-readable amount (e.g., "1.5") into raw integer string. */
export function parseAmountRaw(amount: string | number): string {
  if (typeof amount === 'number') {
    if (!Number.isFinite(amount) || amount < 0) {
      throw new Error(`parseAmountRaw: invalid amount ${amount}`);
    }
    // Convert to raw integer (6 decimals)
    const raw = Math.round(amount * 1_000_000);
    return raw.toString();
  }
  const s = amount.trim();
  if (!/^\d+(\.\d+)?$/.test(s)) {
    throw new Error(`parseAmountRaw: invalid amount string '${amount}'`);
  }
  const [whole, frac = ''] = s.split('.');
  const fracPadded = (frac + '000000').slice(0, 6);
  const raw = BigInt(whole!) * 1_000_000n + BigInt(fracPadded || '0');
  return raw.toString();
}

/** Format a raw amount string as a human-readable OCT string.
 *
 * Handles two formats:
 *   - Raw integer string (e.g., "1500000") → "1.5"
 *   - Decimal OCT string (e.g., "94.231308") → "94.231308" (passed through)
 */
export function formatAmount(rawStr: string): string {
  if (!rawStr || rawStr === '0') return '0';
  // If the string contains a decimal point, it's already in OCT format
  if (rawStr.includes('.')) return rawStr;
  // Otherwise, it's a raw integer — convert to OCT (1 OCT = 1,000,000 raw)
  const raw = BigInt(rawStr);
  const whole = raw / 1_000_000n;
  const frac = raw % 1_000_000n;
  if (frac === 0n) return whole.toString();
  return `${whole}.${frac.toString().padStart(6, '0').replace(/0+$/, '')}`;
}

/** Compute current timestamp in seconds since Unix epoch (matches C++ now_ts). */
export function nowTs(): number {
  return Math.floor(Date.now() / 1000);
}

export { canonicalJsonForTx, computeTxHash };
export type { TransactionFields };
