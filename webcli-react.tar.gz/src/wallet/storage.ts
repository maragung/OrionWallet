/**
 * IndexedDB storage layer for wallet + manifest + tx cache.
 * Replaces the C++ filesystem + LevelDB layer.
 *
 * Schema:
 *   DB name: "webcli-react"
 *   Object stores:
 *     - wallets:    { id: "default", blob: Uint8Array, addrHint: string, name: string }
 *     - manifest:   { id: 0, accounts: [{addr, name, index, pubB64}] }
 *     - tx-cache:   key by `${addr}:${txHash}`, value = JSON tx
 *     - settings:   { id: "settings", rpcUrl, network, ... }
 */
import { openDB, type IDBPDatabase } from 'idb';

const DB_NAME = 'webcli-react';
const DB_VERSION = 1;

export interface StoredWalletEntry {
  id: string; // "default" or addr-hint
  blob: Uint8Array; // encrypted wallet bytes
  addrHint: string; // partial addr for hint (first 8 chars + ...)
  name: string;
  createdAt: number;
}

export interface ManifestEntry {
  addr: string;
  name: string;
  index: number;
  pubB64: string;
  createdAt: number;
}

export interface Manifest {
  id: number; // always 0
  accounts: ManifestEntry[];
  activeAddr: string | null;
  version: number;
}

export interface Settings {
  id: string; // always "settings"
  rpcUrl: string;
  network: 'devnet' | 'mainnet';
  theme: 'dark' | 'light' | 'system';
  lastUsedAddress?: string;
  explorerUrl?: string;
  language?: string; // LanguageCode
}

let dbPromise: Promise<IDBPDatabase> | null = null;

/** Get (or open) the IndexedDB connection. */
export function getDb(): Promise<IDBPDatabase> {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('wallets')) {
          db.createObjectStore('wallets', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('manifest')) {
          db.createObjectStore('manifest', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('tx-cache')) {
          db.createObjectStore('tx-cache', { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'id' });
        }
      },
    });
  }
  return dbPromise;
}

// ===== Wallets store =====

export async function saveWalletEntry(entry: StoredWalletEntry): Promise<void> {
  const db = await getDb();
  await db.put('wallets', entry);
}

export async function loadWalletEntry(id: string = 'default'): Promise<StoredWalletEntry | null> {
  const db = await getDb();
  const entry = await db.get('wallets', id);
  return (entry as StoredWalletEntry) || null;
}

export async function listWalletEntries(): Promise<StoredWalletEntry[]> {
  const db = await getDb();
  const all = await db.getAll('wallets');
  return all as StoredWalletEntry[];
}

export async function deleteWalletEntry(id: string): Promise<void> {
  const db = await getDb();
  await db.delete('wallets', id);
}

// ===== Manifest store =====

export async function loadManifest(): Promise<Manifest> {
  const db = await getDb();
  const m = (await db.get('manifest', 0)) as Manifest | undefined;
  return m ?? { id: 0, accounts: [], activeAddr: null, version: 1 };
}

export async function saveManifest(m: Manifest): Promise<void> {
  const db = await getDb();
  await db.put('manifest', m);
}

export async function addAccountToManifest(entry: ManifestEntry): Promise<Manifest> {
  const m = await loadManifest();
  // Replace if exists (same addr), else append
  const idx = m.accounts.findIndex((a) => a.addr === entry.addr);
  if (idx >= 0) m.accounts[idx] = entry;
  else m.accounts.push(entry);
  if (!m.activeAddr) m.activeAddr = entry.addr;
  await saveManifest(m);
  return m;
}

export async function removeAccountFromManifest(addr: string): Promise<Manifest> {
  const m = await loadManifest();
  m.accounts = m.accounts.filter((a) => a.addr !== addr);
  if (m.activeAddr === addr) {
    m.activeAddr = m.accounts[0]?.addr ?? null;
  }
  await saveManifest(m);
  return m;
}

export async function setActiveAccount(addr: string): Promise<Manifest> {
  const m = await loadManifest();
  if (!m.accounts.find((a) => a.addr === addr)) {
    throw new Error(`setActiveAccount: address ${addr} not in manifest`);
  }
  m.activeAddr = addr;
  await saveManifest(m);
  return m;
}

// ===== Settings store =====

export async function loadSettings(): Promise<Settings> {
  const db = await getDb();
  const s = (await db.get('settings', 'settings')) as Settings | undefined;
  return (
    s ?? {
      id: 'settings',
      rpcUrl: 'https://devnet.octrascan.io/rpc',
      network: 'devnet',
      theme: 'dark',
      explorerUrl: 'https://devnet.octrascan.io',
    }
  );
}

export async function saveSettings(s: Settings): Promise<void> {
  const db = await getDb();
  await db.put('settings', s);
}

// ===== Tx cache store =====

export interface TxCacheEntry {
  key: string; // `${addr}:${txHash}`
  addr: string;
  hash: string;
  tx: unknown; // arbitrary JSON
  receivedAt: number;
}

export async function putTxCache(entry: TxCacheEntry): Promise<void> {
  const db = await getDb();
  await db.put('tx-cache', entry);
}

export async function getTxCache(addr: string, hash: string): Promise<TxCacheEntry | null> {
  const db = await getDb();
  const e = (await db.get('tx-cache', `${addr}:${hash}`)) as TxCacheEntry | undefined;
  return e ?? null;
}

export async function listTxCache(addr: string, limit: number = 100): Promise<TxCacheEntry[]> {
  const db = await getDb();
  const all = (await db.getAll('tx-cache')) as TxCacheEntry[];
  return all
    .filter((e) => e.addr === addr)
    .sort((a, b) => b.receivedAt - a.receivedAt)
    .slice(0, limit);
}

export async function clearTxCache(addr?: string): Promise<void> {
  const db = await getDb();
  if (!addr) {
    await db.clear('tx-cache');
    return;
  }
  const all = (await db.getAll('tx-cache')) as TxCacheEntry[];
  for (const e of all) {
    if (e.addr === addr) await db.delete('tx-cache', e.key);
  }
}

// ===== Maintenance =====

export async function wipeEverything(): Promise<void> {
  const db = await getDb();
  await db.clear('wallets');
  await db.clear('manifest');
  await db.clear('tx-cache');
  await db.clear('settings');
}

/** Close the DB connection (for tests). */
export async function closeDb(): Promise<void> {
  if (dbPromise) {
    const db = await dbPromise;
    db.close();
    dbPromise = null;
  }
}
