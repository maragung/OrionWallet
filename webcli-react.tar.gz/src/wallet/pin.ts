/**
 * PIN validation policy.
 * Ported from main.cpp validate_pin.
 *
 * Rules:
 *   - Length: 8..64 chars
 *   - If length < 15: must contain at least one letter, one digit, and one symbol
 *   - Symbols: any non-alphanumeric character
 *   - If length >= 15: any characters allowed (passphrase-style)
 */
export interface PinValidationResult {
  ok: boolean;
  reason?: string;
}

export function validatePin(pin: string): PinValidationResult {
  if (typeof pin !== 'string') return { ok: false, reason: 'PIN must be a string' };
  if (pin.length < 8) return { ok: false, reason: 'PIN must be at least 8 characters' };
  if (pin.length > 64) return { ok: false, reason: 'PIN must be at most 64 characters' };
  if (pin.length < 15) {
    const hasLetter = /[a-zA-Z]/.test(pin);
    const hasDigit = /[0-9]/.test(pin);
    const hasSymbol = /[^a-zA-Z0-9]/.test(pin);
    if (!hasLetter) return { ok: false, reason: 'PIN < 15 chars must contain a letter' };
    if (!hasDigit) return { ok: false, reason: 'PIN < 15 chars must contain a digit' };
    if (!hasSymbol) return { ok: false, reason: 'PIN < 15 chars must contain a symbol' };
  }
  return { ok: true };
}

/** Throw on invalid PIN. */
export function assertValidPin(pin: string): void {
  const r = validatePin(pin);
  if (!r.ok) throw new Error(`Invalid PIN: ${r.reason}`);
}
