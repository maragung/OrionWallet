# PVAC (Private Verifiable Arithmetic Computation) — WASM Porting Plan

## Status

**Current:** STUB only. All FHE operations throw `PvacNotAvailableError`.

**Goal:** Compile the original C++ `pvac/` directory to WebAssembly via Emscripten,
expose the C API (`pvac_c_api.h`) via `ccall`/`cwrap`, and replace the stub
implementations in `src/pvac/index.ts` with real WASM calls.

## Why a stub?

The PVAC library is ~3000 lines of header-only C++ implementing:
- **ristretto255** group arithmetic (constant-time)
- **bulletproofs** (R1CS, inner-product arguments, range proofs)
- **LPN** (Learning Parity with Noise) — FHE scheme core
- **Toeplitz matrices** (for LPN evaluation)
- **Field arithmetic** (modular prime field operations)
- **Homomorphic encrypt/decrypt/arithmetic/recrypt**
- **Pedersen commitments** and **zero-knowledge proofs**

Re-implementing this in TypeScript would take months and risk subtle bugs.
The correct path is to compile the existing audited C++ to WASM.

## Emscripten Compile Plan

### Prerequisites
- Emscripten SDK (emsdk) installed and activated
- The `pvac/` directory from the original `octra-labs/webcli` repo

### Compile command (target)

```bash
em++ \
  -O3 \
  -std=c++17 \
  -fPIC \
  -I pvac/include \
  -s WASM=1 \
  -s MODULARIZE=1 \
  -s EXPORT_ES6=1 \
  -s EXPORT_NAME="createPvacModule" \
  -s ALLOW_MEMORY_GROWTH=1 \
  -s INITIAL_MEMORY=64MB \
  -s MAXIMUM_MEMORY=512MB \
  -s EXPORTED_RUNTIME_METHODS="['ccall','cwrap','_malloc','_free','getValue','setValue','HEAPU8','HEAP32']" \
  -s EXPORTED_FUNCTIONS="['_pvac_init','_pvac_free','_pvac_encrypt','_pvac_decrypt','_pvac_pedersen_commit','_pvac_make_zero_proof_bound','_pvac_verify_zero_proof','_pvac_ct_sub','_pvac_encrypt_zero','_pvac_serialize_pubkey','_pvac_version']" \
  pvac/pvac_c_api.cpp \
  -o public/wasm/pvac.js
```

This produces:
- `public/wasm/pvac.wasm` — the binary module
- `public/wasm/pvac.js` — the ES6 glue

### Optional: threading

For 2-4x speedup on heavy operations (recrypt, proof generation):
```bash
  -pthread \
  -s PTHREAD_POOL_SIZE=4 \
  -s USE_PTHREADS=1
```
Requires COOP/COEP headers (already set in `vite.config.ts`).

## Loading in the browser

```typescript
// src/pvac/wasm-bridge.ts (to be implemented)
import createPvacModule from '/wasm/pvac.js';

export class WasmPvacBridge implements IPvacBridge {
  private mod: any;
  private handle: number = 0;

  async init(privB64: string): Promise<boolean> {
    this.mod = await createPvacModule();
    const seed = base64Decode(privB64).subarray(0, 32);
    const seedPtr = this.mod._malloc(seed.length);
    this.mod.HEAPU8.set(seed, seedPtr);
    this.handle = this.mod._pvac_init(seedPtr, seed.length);
    this.mod._free(seedPtr);
    return this.handle !== 0;
  }

  encrypt(amount: bigint, seed?: Uint8Array): PvacCipher {
    // Allocate output buffer, call _pvac_encrypt, read result
    // ... see pvac_c_api.h for exact ABI
    throw new Error('TODO: implement after WASM is built');
  }

  // ... other methods
}
```

## Tests

Once the WASM module is available, add a test file:
`tests/unit/pvac-wasm.test.ts` that:
1. Loads the WASM module
2. Runs known test vectors from `pvac/pvac_c_api.cpp`
3. Verifies encrypt → decrypt round-trip
4. Verifies zero-proof generation and verification
5. Verifies homomorphic arithmetic (ct_sub, ct_add)

## Migration checklist

- [ ] Obtain `pvac/` source from `octra-labs/webcli` repo (or upstream license-compatible source)
- [ ] Install Emscripten SDK
- [ ] Compile `pvac.wasm` + `pvac.js` glue
- [ ] Implement `WasmPvacBridge` in `src/pvac/wasm-bridge.ts`
- [ ] Wire `loadPvacWasm()` in `src/pvac/index.ts` to dynamically import the glue
- [ ] Add Web Worker wrapper for heavy operations (avoid UI freeze)
- [ ] Add test vectors from C++ test suite
- [ ] Benchmark encrypt/decrypt latency in browser
- [ ] Document browser memory requirements (recommend ≥4GB RAM)

## License note

The original `pvac/` source is licensed under GPL-2.0 (with OpenSSL exemption).
Any WASM-compiled artifact inherits this license. Distribute accordingly.
